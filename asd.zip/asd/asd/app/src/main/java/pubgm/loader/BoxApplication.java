package pubgm.loader;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import java.io.File;

import top.niunaijun.blackbox.BlackBoxCore;

import top.niunaijun.blackbox.app.configuration.ClientConfiguration;


public class BoxApplication extends Application {

     @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        try {
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() {
                @Override
                public String getHostPackageName() {
                    return base.getPackageName();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        BlackBoxCore.get().doCreate();
    }
}
