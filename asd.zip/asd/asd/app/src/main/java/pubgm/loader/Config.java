package pubgm.loader;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class Config {
    public static String STATUS_BY = "online";
    public static final int USER_ID = 0;
    public static final int[] GAME_LIST_ICON = new int[]{ R.drawable.pubg_global, R.drawable.pubg_korea};
    public static final String GAME_LIST_PKG[] = {"com.tencent.ig","com.pubg.krmobile", "com.vng.pubgmobile", "com.rekoo.pubgm", "com.pubg.imobile"};
}
