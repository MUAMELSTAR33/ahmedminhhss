package pubgm.loader.activity;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import com.google.android.material.textfield.TextInputLayout;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.topjohnwu.superuser.Shell;

import org.lsposed.lsparanoid.Obfuscate;

import java.io.File;
import java.util.ArrayList;
import java.util.Locale;

import pubgm.loader.Component.DownC;
import pubgm.loader.Component.Prefs;
import pubgm.loader.R;
import pubgm.loader.utils.ActivityCompat;
import pubgm.loader.utils.FLog;
import pubgm.loader.utils.LanguageItem;
import pubgm.loader.utils.LanguageSpinnerAdapter;
import pubgm.loader.utils.myTools;

import static pubgm.loader.server.ApiServer.URLJSON;
import static pubgm.loader.server.ApiServer.getOwner;
import static pubgm.loader.server.ApiServer.getTelegram;
import static pubgm.loader.server.ApiServer.mainURL;

@Obfuscate
public class LoginActivity extends ActivityCompat {

    static {
        try {
            System.loadLibrary("master");
            FLog.info("Native lib loaded!");
        } catch(UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }

    private myTools m;
    private static final String USER = "USER";
    private static final String PASS = "PASS";
    public static String USERKEY, PASSKEY;
    LinearLayoutCompat btnSignIn;
    private Prefs prefs;
    private Spinner languageSpinner;
    public static int REQUEST_OVERLAY_PERMISSION = 5469;

@Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setLightStatusBar(this);
    m = new myTools(this);
    setContentView(R.layout.activity_login);
    initializeLanguageSpinner();
    initDesign();
    OverlayPermision();
}
    public void initDesign() {
    prefs = Prefs.with(this);
    final Context m_Context = this;
    final EditText textUsername = findViewById(R.id.textUsername);
    final EditText textPassword = findViewById(R.id.textPassword);
    final TextInputLayout pasteOrCut = findViewById(R.id.textInputUsername);

    textUsername.setText(prefs.read(USER, ""));
    textPassword.setText(prefs.read(PASS, ""));
    pasteOrCut.setEndIconDrawable(R.drawable.ic_paste);

    btnSignIn = findViewById(R.id.loginBtn);
    btnSignIn.setOnClickListener(v -> {
        if (!textUsername.getText().toString().isEmpty() && !textPassword.getText().toString().isEmpty()) {
            prefs.write(USER, textUsername.getText().toString());
            prefs.write(PASS, textPassword.getText().toString());
            String userKey = textUsername.getText().toString().trim();
            String passKey = textPassword.getText().toString().trim();
            Login(LoginActivity.this, userKey);
            USERKEY = userKey;
            PASSKEY = passKey;
        }
        if (textUsername.getText().toString().isEmpty())
            textUsername.setError(getString(R.string.please_enter_username));
        if (textPassword.getText().toString().isEmpty())
            textPassword.setError(getString(R.string.please_enter_password));
    });

    pasteOrCut.setEndIconOnClickListener(view -> {
        if (!textUsername.getText().toString().isEmpty() || !textPassword.getText().toString().isEmpty()) {
            textUsername.setText("");
            textPassword.setText("");
            pasteOrCut.setEndIconDrawable(R.drawable.ic_paste);
        } else {
            ClipboardManager clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboardManager != null && clipboardManager.hasPrimaryClip()) {
                ClipData clipData = clipboardManager.getPrimaryClip();
                if (clipData != null && clipData.getItemCount() > 0) {
                    CharSequence pastedText = clipData.getItemAt(0).getText();
                    if (pastedText != null && pastedText.length() > 0) {
                        textUsername.setText(pastedText.toString());
                        textPassword.setText(pastedText.toString());
                        pasteOrCut.setEndIconDrawable(R.drawable.ic_close);
                    } else {
                        Toast.makeText(m_Context, getString(R.string.please_copy_licence_and_paste), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(m_Context, "الحافظة فارغة", Toast.LENGTH_SHORT).show();
                }
            }
        }
    });

        LinearLayoutCompat getKey = findViewById(R.id.telegram);
        getKey.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(getOwner()));
            startActivity(intent);
        });

        LinearLayoutCompat store = findViewById(R.id.store);
        store.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(getTelegram()));
            startActivity(intent);
        });
    }

    private void initializeLanguageSpinner() {
        languageSpinner = findViewById(R.id.splang);
        ArrayList<LanguageItem> languageList = new ArrayList<>();
        languageList.add(new LanguageItem("English", "en"));
        languageList.add(new LanguageItem("Arabic", "ar"));

        LanguageSpinnerAdapter adapter = new LanguageSpinnerAdapter(this, android.R.layout.simple_spinner_item, languageList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(adapter);

        String currentLang = m.getSt("myKey", "mapLang", "en");
        if (currentLang == null) currentLang = Locale.getDefault().getLanguage();

        for (int i = 0; i < languageList.size(); i++) {
            if (languageList.get(i).getCode().equals(currentLang)) {
                languageSpinner.setSelection(i);
                break;
            }
        }

        languageSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            boolean isInitialSelection = true;
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (isInitialSelection) { isInitialSelection = false; return; }
                LanguageItem selectedLanguage = (LanguageItem) parent.getItemAtPosition(position);
                String langCode = selectedLanguage.getCode();
                if (!langCode.equals(m.getSt("myKey", "mapLang", "en"))) {
                    m.setLocale(LoginActivity.this, langCode);
                    m.setSt("myKey", "mapLang", langCode);
                    recreate();
                }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        languageSpinner.setBackground(getDrawable(R.drawable.custom_spinner_background));
    }

    private void setLightStatusBar(Activity activity) {
        activity.getWindow().setStatusBarColor(Color.parseColor("#FFFFFF"));
        activity.getWindow().setNavigationBarColor(Color.parseColor("#FFFFFF"));
    }

    public void OverlayPermision() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(this);
                builder.setMessage(R.string.please_allow_permision_floating);
                builder.setPositiveButton(R.string.yes, (p1, p2) -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                    startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
                });
                builder.setCancelable(false);
                builder.show();
            }
        }
    }

    private static void Login(final LoginActivity m_Context, final String userKey) {
        LayoutInflater inflater = LayoutInflater.from(m_Context);
        View viewloading = inflater.inflate(R.layout.animation_login, null);

        AlertDialog dialogloading = new AlertDialog.Builder(m_Context, 5)
                .setView(viewloading)
                .setCancelable(false)
                .create();
        if (dialogloading.getWindow() != null) {
            dialogloading.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        dialogloading.show();

        final Handler loginHandler = new Handler(Looper.getMainLooper()) {
            @SuppressLint("HandlerLeak")
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 0) {
                    new DownC(m_Context) {
                        @Override
                        protected void onPostExecute(String result) {
                            super.onPostExecute(result);
                            if ("SUCCESS".equals(result)) {
                                File dir = m_Context.getFilesDir();
                                new File(dir, "libpubgm.so").delete();
                                new File(dir, "libbgmi.so").delete();
                                Intent i = new Intent(m_Context, NeroActivity.class);
                                m_Context.startActivity(i);
                            } else {
                                Toast.makeText(m_Context, "Download failed: " + result, Toast.LENGTH_SHORT).show();
                            }
                        }
                    }.execute(URLJSON(), mainURL());
                } else if (msg.what == 1) {
                    dialogloading.dismiss();
                    AlertDialog.Builder builder = new AlertDialog.Builder(m_Context, 5);
                    builder.setTitle(m_Context.getString(R.string.erorserver));
                    builder.setMessage(msg.obj.toString());
                    builder.setCancelable(false);
                    builder.setPositiveButton("OK", (dialog, which) -> {});
                    builder.show();
                }
            }
        };

        new Thread(() -> {
            String result = native_Check(m_Context, userKey);
            if ("OK".equals(result)) loginHandler.sendEmptyMessage(0);
            else {
                Message msg = new Message();
                msg.what = 1;
                msg.obj = result;
                loginHandler.sendMessage(msg);
            }
        }).start();
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_STORAGE) OverlayPermision();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY_PERMISSION) InstllUnknownApp();
        else if (requestCode == REQUEST_MANAGE_UNKNOWN_APP_SOURCES) if (!isPermissionGaranted()) takeFilePermissions();
    }

    private static native String native_Check(Context context, String userKey);
}