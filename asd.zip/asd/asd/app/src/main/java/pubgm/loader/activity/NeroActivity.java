package pubgm.loader.activity;
import androidx.appcompat.app.AlertDialog;
import android.widget.ArrayAdapter;
import android.view.View;
import top.niunaijun.blackbox.BlackBoxCore;
import android.view.ViewGroup;
import android.widget.TextView;
import static pubgm.loader.Config.GAME_LIST_ICON;
import static pubgm.loader.R.id.remaining_time;
import static pubgm.loader.activity.LoginActivity.USERKEY;
import static pubgm.loader.activity.SplashActivity.mahyong;
import static pubgm.loader.server.ApiServer.EXP;
import static pubgm.loader.server.ApiServer.URLJSON;
import static pubgm.loader.server.ApiServer.mainURL;
import static pubgm.loader.utils.FLog.TAG;
import static com.topjohnwu.superuser.internal.UiThreadHandler.handler;
import top.niunaijun.blackbox.BlackBoxCore;
import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.ScaleAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.blankj.molihuan.utilcode.util.SnackbarUtils;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import pubgm.loader.Component.DownC;
import pubgm.loader.R;

import pubgm.loader.adapter.RecyclerViewAdapter;
import pubgm.loader.floating.FloatingService;
import pubgm.loader.floating.Overlay;
import pubgm.loader.floating.ToggleAim;
import pubgm.loader.floating.ToggleBullet;
import pubgm.loader.floating.ToggleSimulation;

import pubgm.loader.server.ApiServer;
import pubgm.loader.utils.ActivityCompat;
import pubgm.loader.utils.FLog;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.skydoves.powerspinner.OnSpinnerItemSelectedListener;
import com.skydoves.powerspinner.PowerSpinnerView;
import com.topjohnwu.superuser.Shell;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


import org.lsposed.lsparanoid.Obfuscate;

/**************************
 * BUILD ON Android Studio
 * TELEGRAM : TURBOO70
 * *************************/

@Obfuscate
public class NeroActivity extends ActivityCompat {

    private static final int BUFFER_SIZE = 0;
    public static String socket;
    public static String daemonPath;
    public static boolean fixinstallint = false;
    public static boolean check = false;
    public static int hiderecord = 0;
    public static int skin = 0;
    static NeroActivity instance;
    

    static {
        try {
            System.loadLibrary("master");
        } catch(UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }

    private PowerSpinnerView powerSpinnerView;
    private MaterialButton installKernelButton;
    private TextView importantApps;
    private static final int REQUEST_PERMISSIONS = 1;
    String[] packageapp = {"com.tencent.ig", "com.pubg.krmobile", "com.vng.pubgmobile", "com.rekoo.pubgm","com.pubg.imobile"};
    String[] appPackage = {"com.tencent.ig","com.pubg.krmobile","com.pubg.imobile","com.twitter.android","mark.via.gp","com.vng.pubgmobile","com.rekoo.pubgm","com.your.app","telegram @AboudUn0"};
    public String nameGame = "PROTECTION GLOBAL";
    public String CURRENT_PACKAGE = "";
    public LinearProgressIndicator progres;
    public CardView enable, disable;
    public static int gameint = 1;
    public static int bitversi = 64;
    public static boolean noroot = false;
    public static int device = 1;
    public static String game = "com.tencent.ig";
    TextView root;
    public static int checkesp;
    public static boolean kernel = false;
    public static boolean Ischeck = false;
    public LinearLayout container;
    public static String modeselect;
    BlackBoxCore blackboxCore;
    Context ctx;
    public static NeroActivity get() {
        return instance;
    }
    private AppCompatSpinner spinnerLanguage;
@Override
protected void onCreate(@Nullable Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_navigation);
    init();
    initMenu1();
    initMenu2();
    Loadssets();
    devicecheck();
    loadAssets("socu64");
    if (!mahyong){
        finish();
        finishActivity(1);
    }

    instance = this;
    isLogin = true;
    blackboxCore = BlackBoxCore.get();
        blackboxCore.doCreate();

    
    importantApps = findViewById(R.id.importantApps);

    importantApps.setOnClickListener(v -> {
        String[] apps = {"تويتر", "فيسبوك", "تثبيت GMS"};
        Integer[] appIcons = {R.drawable.tw, R.drawable.fb, R.drawable.via};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("اختار تطبيقك");

        builder.setAdapter(new ArrayAdapter<String>(this, R.layout.custom_dialog_item, R.id.label, apps) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = getLayoutInflater().inflate(R.layout.custom_dialog_item, parent, false);
                TextView label = view.findViewById(R.id.label);
                ImageView icon = view.findViewById(R.id.icon);
                label.setText(apps[position]);
                icon.setImageResource(appIcons[position]);
                label.setTextColor(getResources().getColor(R.color.black));
                label.setTextSize(16);
                return view;
            }
        }, (dialog, which) -> {
            String selectedpkg = "";
            switch (which) {
                case 0:
                    selectedpkg = "com.twitter.android";
                    showTwitterOptionsDialog(selectedpkg);
                    return;
                case 1:
                    selectedpkg = "fhjd";
                    break;
                case 2:
                    selectedpkg = "cjjdjdjd";
                    break;
            }
            if (!selectedpkg.isEmpty()) showOptionsDialog(selectedpkg);
        });

        builder.show();
    });
}
private void showOptionsDialog(String pkg){
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle("خيارات");
    String[] options = {"تثبيت", "فتح", "مسح"};
    builder.setItems(options, (dialog, which) -> {
        switch (which){
            case 0: installPackage(pkg); break;
            case 1: launchApk(pkg); break;
            case 2: uninstallPackage(pkg); break;
        }
    });
    builder.show();
}

public void devicecheck(){
    root = findViewById(R.id.textroot);
    container = findViewById(R.id.container);
    LinearLayout menuroot = findViewById(R.id.menuantiban);

    if (Shell.rootAccess()){
        FLog.info("Root granted");
        modeselect = "روت -" + " الاندرويد" + Build.VERSION.RELEASE;
        root.setText(getString(R.string.root) );
        container.setVisibility(View.GONE);
        menuroot.setVisibility(View.VISIBLE);
        Ischeck = true;
        noroot = true;
        device = 1;
    } else {
        FLog.info("Root not granted");
        modeselect = "بدون روت -" + " الاندرويد " + Build.VERSION.RELEASE;
        root.setText(getString(R.string.notooroot));
        doInitRecycler();
        container.setVisibility(View.VISIBLE);
        menuroot.setVisibility(View.GONE);
        Ischeck = false;
        device = 2;
    }
}

private void showTwitterOptionsDialog(String pkg) {
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle("Twitter Options");
    String[] options = {"تثبيت", "فتح", "مسح"};
    builder.setItems(options, (dialog, which) -> {
        switch (which) {
            case 0: installPackage(pkg); break;
            case 1: launchApk(pkg); break;
            case 2: uninstallPackage(pkg); break;
        }
    });
    builder.show();
}

private void installPackage(String pkg) {
    blackboxCore.installPackageAsUser(pkg, 0);
    Toast.makeText(this, "Installing " + pkg + "...", Toast.LENGTH_SHORT).show();
}

private void launchApk(String pkg) {
    if (blackboxCore.isInstalled(pkg, 0)) blackboxCore.launchApk(pkg, 0);
    else Toast.makeText(this, "App is not installed", Toast.LENGTH_SHORT).show();
}

private void uninstallPackage(String pkg) {
    if (blackboxCore.isInstalled(pkg, 0)) {
        blackboxCore.uninstallPackageAsUser(pkg, 0);
        Toast.makeText(this, "Uninstall requested for " + pkg, Toast.LENGTH_SHORT).show();
    } else Toast.makeText(this, "App is not installed", Toast.LENGTH_SHORT).show();
}


    @SuppressLint("SetTextI18n")
    void initMenu1(){
        ImageView start = findViewById(R.id.starthack);
        ImageView stop =  findViewById(R.id.stophack);
        LinearLayout global =  findViewById(R.id.global);
        LinearLayout korea =  findViewById(R.id.korea);
        LinearLayout vietnam =  findViewById(R.id.vietnam);
        LinearLayout taiwan =  findViewById(R.id.taiwan);
        LinearLayout india =  findViewById(R.id.india);
        LinearLayout layoutprtc =  findViewById(R.id.layoutprtc);
        LinearLayout menuselectesp =  findViewById(R.id.menuselectesp);
        LinearLayout protection =  findViewById(R.id.protection);
        TextView textversions =  findViewById(R.id.textversions1);
        ImageView imgs1 =  findViewById(R.id.imgs1);
        RadioGroup modesp = findViewById(R.id.groupmode);
        RadioGroup versionesp = findViewById(R.id.groupesp);


        if (!Shell.rootAccess()){
            menuselectesp.setVisibility(View.GONE);
        }else{
            menuselectesp.setVisibility(View.VISIBLE);
        }
        protection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
           // launchbypass();

            }
        });


        modesp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.system:
                        kernel = false;
                        checkesp = 1;
                        break;
                    case R.id.kernel:
                        kernel = true;
                        checkesp = 2;
                        break;
                }
            }
        });

        versionesp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.esp64:
                        bitversi = 64;
                        checkesp = 1;
                        break;
                    case R.id.esp32:
                        bitversi = 32;
                        checkesp = 2;
                        break;
                }
            }
        });




        start.setOnClickListener(v -> {
            toastImage(R.drawable.ic_check, getString(R.string.start_floating_success));
            startPatcher();

            start.setVisibility(View.GONE);
            stop.setVisibility(View.VISIBLE);
        });

        stop.setOnClickListener(v -> {
            stopPatcher();
            toastImage(R.drawable.ic_error, getString(R.string.stop_floating_success));

            start.setVisibility(View.VISIBLE);
            stop.setVisibility(View.GONE);
        });



    }

    @SuppressLint("ResourceAsColor")
    void initMenu2(){

        // LinearLayout updatesresource = findViewById(R.id.updatesresource);
        LinearLayout layoutother = findViewById(R.id.layoutother);
        TextView key = (TextView) findViewById(R.id.user_key);
        TextView time = (TextView) findViewById(remaining_time);
        TextView brand = (TextView) findViewById(R.id.devices_brand);
        TextView os = (TextView) findViewById(R.id.os_version);
        TextView kernel = (TextView) findViewById(R.id.kernelversiontxt);

        String user_keys = USERKEY;
        if (user_keys.length() > 2) {
            user_keys = user_keys.substring(0, user_keys.length() - 4);
            user_keys += "****";
        }

        key.setText(user_keys);
        brand.setText(Build.BRAND);
        os.setText(Build.VERSION.RELEASE);
        String kernelVersion = System.getProperty("os.version");
        kernel.setText(kernelVersion);
        StartCountDown(time);
        

        final ToggleButton hide_recorder = findViewById(R.id.hide_recorder);
        hide_recorder.setChecked(getPref().readBoolean("anti_recorder"));
        hide_recorder.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                getPref().writeBoolean("anti_recorder", isChecked);
                SnackbarUtils.with(buttonView).setBgColor(R.color.background).setMessage("قم بلترسيت لكي يعمل الاخفاء.").setMessageColor(Color.WHITE).setAction("حسنا", v-> {
                    restartApp(NeroActivity.class.getSimpleName());
                }).show();
            }
        });

    }


    private Runnable runnable;
    Handler handler2 = new Handler();

    void StartCountDown(TextView time) {
        new Handler().postDelayed(new Runnable() {
            public void run() {
                try {
                    handler.postDelayed(this, 1000);
                    long duration = Long.parseLong(EXP());
                    long now = Calendar.getInstance().getTimeInMillis();
                    long distance = duration - now;
                    long days = distance / (24 * 60 * 60 * 1000);
                    long hours = distance / (60 * 60 * 1000) % 24;
                    long minutes = distance / (60 * 1000) % 60;
                    long seconds = distance / 1000 % 60;

                    if (distance < 0) {
                        runOnUiThread(() -> {
                            Toast.makeText(NeroActivity.get(), "Upss error distance...", Toast.LENGTH_LONG).show();
                            handler2.removeCallbacks(runnable);
                            System.exit(0);
                        });
                    } else {
                        int textColor = Color.WHITE;
                        if (days == 0 && hours == 0 && minutes < 60) {
                            textColor = Color.YELLOW;
                        }

                        if (days == 0 && hours == 0 && minutes < 30) {
                            textColor = Color.RED;
                        }
                        //expires = String.format("%02d:%02d:%02d:%02d", days, hours, minutes, seconds);
                        runOnUiThread(() -> {
                            time.setText(String.format("%02d:%02d:%02d:%02d", days, hours, minutes, seconds));
                        });
                    }
                } catch(Exception err) {

                }
            }
        }, 0);
        handler2.postAtTime(runnable, 6000);
    }



    void gameversion(LinearLayout a, LinearLayout b, LinearLayout c, LinearLayout d, LinearLayout e){
        a.setBackgroundResource(R.drawable.button_coming);
        b.setBackgroundResource(R.drawable.button_normal);
        c.setBackgroundResource(R.drawable.button_normal);
        d.setBackgroundResource(R.drawable.button_normal);
        e.setBackgroundResource(R.drawable.button_normal);
    }



    void init() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        LinearLayout menu1 = findViewById(R.id.imenu1);
        LinearLayout menu2 = findViewById(R.id.imenu2);

        // Set the initial state
        menu1.setVisibility(View.VISIBLE);
        menu2.setVisibility(View.GONE);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            // Get the item view to animate just the icon and text
            View itemView = bottomNavigationView.findViewById(item.getItemId());
            if (itemView != null) {
                animateNavItem(itemView);

            }

            int itemId = item.getItemId();

            if (itemId == R.id.navhome) {
                menu1.setVisibility(View.VISIBLE);
                menu2.setVisibility(View.GONE);
                return true;
            }




            return false;
        });
        bottomNavigationView.setSelectedItemId(R.id.navhome);
    }

    // Alternative animation approach using AnimatorSet
    private void animateNavItem(View view) {
        ObjectAnimator scaleDownX = ObjectAnimator.ofFloat(view, "scaleX", 1f, 0.8f);
        ObjectAnimator scaleDownY = ObjectAnimator.ofFloat(view, "scaleY", 1f, 0.8f);
        ObjectAnimator scaleUpX = ObjectAnimator.ofFloat(view, "scaleX", 0.8f, 1f);
        ObjectAnimator scaleUpY = ObjectAnimator.ofFloat(view, "scaleY", 0.8f, 1f);

        scaleDownX.setDuration(100);
        scaleDownY.setDuration(100);
        scaleUpX.setDuration(100);
        scaleUpY.setDuration(100);

        AnimatorSet scaleDown = new AnimatorSet();
        scaleDown.play(scaleDownX).with(scaleDownY);

        AnimatorSet scaleUp = new AnimatorSet();
        scaleUp.play(scaleUpX).with(scaleUpY);

        AnimatorSet fullAnimation = new AnimatorSet();
        fullAnimation.play(scaleDown).before(scaleUp);
        fullAnimation.start();
    }



    ////////////////////////// Load Json ////////////////////////////////////////
    public void doInitRecycler() {
        doShowProgress(true);
        ArrayList<Integer> imageValues = new ArrayList<Integer>();
        ArrayList<String> titleValues = new ArrayList<String>();
        ArrayList<String> versionValues = new ArrayList<String>();
        ArrayList<String> statusValues = new ArrayList<String>();
        ArrayList<String> packageValues = new ArrayList<String>();
        try {
            String jsonLocation = loadJSONFromAsset("games.json");
            JSONObject jsonobject = new JSONObject(jsonLocation);
            JSONArray jarray = jsonobject.getJSONArray("gamesList");
            for (int i = 0; i < jarray.length(); i++) {
                JSONObject jb = (JSONObject) jarray.get(i);
                String title = jb.getString("title");
                String packageName = jb.getString("package");
                String version = jb.getString("version");
                String status = jb.getString("status");
                imageValues.add(GAME_LIST_ICON[i]);
                titleValues.add(title);
                versionValues.add(version);
                statusValues.add(status);
                packageValues.add(packageName);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (Exception e2) {
            e2.printStackTrace();
        }
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, imageValues, titleValues, versionValues, statusValues, packageValues);
        RecyclerView myView = (RecyclerView) findViewById(R.id.recyclerview);
        myView.setHasFixedSize(true);
        myView.setAdapter(adapter);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.HORIZONTAL);
        myView.setLayoutManager(llm);
    }

    public void Exec(String path, String toast) {
        try {
            ExecuteElf("su -c chmod 777 " + getFilesDir() + path);
            ExecuteElf("su -c " + getFilesDir() + path);
            ExecuteElf("chmod 777 " + getFilesDir() + path);
            ExecuteElf(  getFilesDir() + path);
            toastImage(R.drawable.ic_check, toast);
        } catch (Exception e) {
        }
    }

    private void ExecuteElf(String shell) {
        try {
            Runtime.getRuntime().exec(shell, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void Loadssets() {;
        MoveAssets(getFilesDir() + "/", "socu64");
        MoveAssets(getFilesDir() + "/", "TW");
        MoveAssets(getFilesDir() + "/", "kernels64");
    }

    private boolean MoveAssets(String outPath, String fileName) {
        File file = new File(outPath);
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.e("--Method--", "copyAssetsSingleFile: cannot create directory.");
                return false;
            }
        }
        try {
            InputStream inputStream = getAssets().open(fileName);
            File outFile = new File(file, fileName);
            FileOutputStream fileOutputStream = new FileOutputStream(outFile);
            byte[] buffer = new byte[1024];
            int byteRead;
            while (-1 != (byteRead = inputStream.read(buffer))) {
                fileOutputStream.write(buffer, 0, byteRead);
            }
            inputStream.close();
            fileOutputStream.flush();
            fileOutputStream.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String loadJSONFromAsset(String fileName) {
        String json = null;
        try {
            InputStream is = getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }


 

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopService(new Intent(NeroActivity.get(), FloatingService.class));
        stopService(new Intent(NeroActivity.get(), Overlay.class));
        stopService(new Intent(NeroActivity.get(), ToggleBullet.class));
        stopService(new Intent(NeroActivity.get(), ToggleAim.class));
        stopService(new Intent(NeroActivity.get(), ToggleSimulation.class));

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Toast.makeText(this, getString(R.string.please_click_icon_logout_for_exit), Toast.LENGTH_SHORT).show();
    }

    public LinearProgressIndicator getProgresBar() {
        if (progres == null) {
            progres = findViewById(R.id.progress);
        }
        return progres;
    }

    public void doShowProgress(boolean indeterminate) {
        if (progres == null) {
            return;
        }
        progres.setVisibility(View.VISIBLE);
        progres.setIndeterminate(indeterminate);

        if (!indeterminate) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                progres.setMin(0);
            }
            progres.setMax(100);
        }
    }

    public void doHideProgress() {
        if (progres == null) {
            return;
        }
        progres.setIndeterminate(true);
        progres.setVisibility(View.GONE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        } else {
            showSystemUI();
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    private void showSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    private boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (FloatingService.class.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    private void startPatcher() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(NeroActivity.get())) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 123);
            } else {
                startFloater();
            }
        }
    }

public void triggerFloaterFromAdapter() {
    startPatcher();  // or startFloater(); depending on your need
}

        
    private void startFloater() {

            if (kernel){
                if(bitversi == 64) {
                    loadAssets("kernels64");
                }else if(bitversi == 32){
                    loadAssets("kernels32");
                }
            }else{
                if(bitversi == 64) {
                    loadAssets("socu64");
                }else if(bitversi == 32){
                    loadAssets("socu32");
                }
            }
            String CMD =    "rm -rf  /data/data/" + game + "/files;\n" +
                    "touch  /data/data/" + game + "/files;\n";
            Shell.su(CMD).submit();
            startService(new Intent(NeroActivity.get(), FloatingService.class));
    
    }

    private void stopPatcher() {
        stopService(new Intent(NeroActivity.get(), FloatingService.class));
        stopService(new Intent(NeroActivity.get(), Overlay.class));
        stopService(new Intent(NeroActivity.get(), ToggleAim.class));
        stopService(new

                Intent(NeroActivity.get(), ToggleBullet.class));
        stopService(new Intent(NeroActivity.get(), ToggleSimulation.class));
    }

    public void loadAssets(String sockver) {
        daemonPath = NeroActivity.this.getFilesDir().toString() + "/" + sockver;
        socket = daemonPath;
        try {
            Runtime.getRuntime().exec("chmod 777 " + daemonPath);
        } catch (IOException e) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        CountTimerAccout();
        boolean needsRecreate = getSharedPreferences("app_prefs", MODE_PRIVATE)
                .getBoolean("needs_recreate", false);
        if (needsRecreate) {
            getSharedPreferences("app_prefs", MODE_PRIVATE)
                    .edit()
                    .putBoolean("needs_recreate", false)
                    .apply();
        }
    }

    private void CountTimerAccout() {
        if (EXP().isEmpty()) {
            if (instance != null) {
                instance.finishAffinity();
            }
            return;
        }
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    handler.postDelayed(this, 1000); // Update every second

                    String xprValue = EXP();

                    // Parse the xpr() string into a Date object
                    long duration = 0;
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                    try {
                        Date date = sdf.parse(xprValue);
                        if (date != null) {
                            duration = date.getTime(); // Convert to milliseconds
                        } else {
                            Log.e(TAG, "Failed to parse xpr value: " + xprValue);
                            return;
                        }
                    } catch (ParseException e) {
                        Log.e(TAG, "Invalid date format from xpr: " + xprValue, e);
                        return;
                    }

                    long now = android.icu.util.Calendar.getInstance().getTimeInMillis();
                    long remainingTime = duration - now;

                    if (remainingTime < 0) {
                        if (instance != null) {
                            instance.finishAffinity();
                        }
                        return;
                    }

                    long days = remainingTime / (24 * 60 * 60 * 1000);
                    long hours = (remainingTime / (60 * 60 * 1000)) % 24;
                    long minutes = (remainingTime / (60 * 1000)) % 60;
                    long seconds = (remainingTime / 1000) % 60;

                    updateCountdownUI(days, hours, minutes, seconds);
                } catch (Exception e) {
                    Log.e(TAG, "Error in countdown timer: ", e);
                }
            }
        });
    }

    private void updateCountdownUI(long days, long hours, long minutes, long seconds) {
        // Ensure you're working on the main thread to update the UI
        if (instance != null && !instance.isFinishing() && !instance.isDestroyed()) {
            // Get the TextViews for displaying the countdown
            TextView daysView = findViewById(R.id.days);
            TextView hoursView = findViewById(R.id.hours);
            TextView minutesView = findViewById(R.id.minutes);
            TextView secondsView = findViewById(R.id.second);

            // Update the days part
            if (daysView != null) {
                daysView.setText(String.format("%02d", days)); // Format to two digits (e.g., 02)
            }

            // Update the hours part
            if (hoursView != null) {
                hoursView.setText(String.format("%02d", hours)); // Format to two digits (e.g., 01)
            }

            // Update the minutes part
            if (minutesView != null) {
                minutesView.setText(String.format("%02d", minutes)); // Format to two digits (e.g., 01)
            }

            // Update the seconds part
            if (secondsView != null) {
                secondsView.setText(String.format("%02d", seconds)); // Format to two digits (e.g., 01)
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (!(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                finish();
            }
        }
    }
    private int getKernelIndex(String kernelVersion) {
        if (kernelVersion.contains("4.9.186")) return 0;
        if (kernelVersion.contains("4.14.117")) return 1;
        if (kernelVersion.contains("4.14.180")) return 2;
        if (kernelVersion.contains("4.14.186")) return 3;
        if (kernelVersion.contains("4.14.186b")) return 4;
        if (kernelVersion.contains("4.14.186c")) return 5;
        if (kernelVersion.contains("4.19.81")) return 6;
        if (kernelVersion.contains("4.19.113")) return 7;
        if (kernelVersion.contains("4.19.113c")) return 8;
        if (kernelVersion.contains("4.19.157")) return 9;
        if (kernelVersion.contains("4.19.157b")) return 10;
        if (kernelVersion.contains("4.19.157-安卓13")) return 11;
        if (kernelVersion.contains("4.19.191-安卓13")) return 12;
        if (kernelVersion.contains("5.4.210-安卓13")) return 13;
        if (kernelVersion.contains("5.15")) return 14;
        if (kernelVersion.contains("5.15b")) return 15;
        if (kernelVersion.contains("5.10")) return 16;
        if (kernelVersion.contains("5.10b")) return 17;
        if (kernelVersion.contains("5.10-安卓13-GooglePixel")) return 18;
        if (kernelVersion.contains("5.4.61~250")) return 19;
        if (kernelVersion.contains("5.4.86~250")) return 20;
        if (kernelVersion.contains("5.4.147~250")) return 21;
        return -1;
    }


    private void installKernel(int index) {
        String kernelFileName = "";
        switch (index) {
            case 0:
                kernelFileName = "4.9.186_fix.ko.sh";
                break;
            case 1:
                kernelFileName = "4.14.117.ko.sh";
                break;
            case 2:
                kernelFileName = "4.14.180.ko.sh";
                break;
            case 3:
                kernelFileName = "4.14.186.ko.sh";
                break;
            case 4:
                kernelFileName = "4.14.186b.ko.sh";
                break;
            case 5:
                kernelFileName = "4.14.186c.ko.sh";
                break;
            case 6:
                kernelFileName = "4.19.81.ko.sh";
                break;
            case 7:
                kernelFileName = "4.19.113.ko.sh";
                break;
            case 8:
                kernelFileName = "4.19.113c.ko.sh";
                break;
            case 9:
                kernelFileName = "4.19.157.ko.sh";
                break;
            case 10:
                kernelFileName = "4.19.157b.ko.sh";
                break;
            case 11:
                kernelFileName = "4.19.157-安卓13.ko.sh";
                break;
            case 12:
                kernelFileName = "4.19.191-安卓13.ko.sh";
                break;
            case 13:
                kernelFileName = "5.4.210-安卓13.ko.sh";
                break;
            case 14:
                kernelFileName = "5.15.ko.sh";
                break;
            case 15:
                kernelFileName = "5.15b.ko.sh";
                break;
            case 16:
                kernelFileName = "5.10.ko.sh";
                break;
            case 17:
                kernelFileName = "5.10b.ko.sh";
                break;
            case 18:
                kernelFileName = "5.10-安卓13-GooglePixel.ko.sh";
                break;
            case 19:
                kernelFileName = "5.4.61~250.ko.sh";
                break;
            case 20:
                kernelFileName = "5.4.86~250.ko.sh";
                break;
            case 21:
                kernelFileName = "5.4.147~250.ko.sh";
                break;
        }

        MoveAssets(getFilesDir() + "/", kernelFileName);
        Exec("/"+ kernelFileName, "Kernel Driver Success");
    }



}