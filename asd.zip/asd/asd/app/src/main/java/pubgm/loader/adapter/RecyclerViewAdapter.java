package pubgm.loader.adapter;

import static pubgm.loader.activity.NeroActivity.gameint;
import static pubgm.loader.utils.ActivityCompat.toastImage;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.blankj.molihuan.utilcode.util.ToastUtils;
import com.blankj.utilcode.util.AppUtils;
import pubgm.loader.R;
import pubgm.loader.activity.NeroActivity;
import pubgm.loader.floating.FloatingService;
import pubgm.loader.utils.FLog;
import pubgm.loader.utils.UiKit;

import org.lsposed.lsparanoid.Obfuscate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;

@Obfuscate
public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {
    public NeroActivity activity;
    public ArrayList<Integer> imageValues;
    public ArrayList<String> titleValues;
    public ArrayList<String> versionValues;
    public ArrayList<String> statusValues;
    public ArrayList<String> packageValues;

    public RecyclerViewAdapter(NeroActivity activity,
                               ArrayList<Integer> imageValues,
                               ArrayList<String> titleValues,
                               ArrayList<String> versionValues,
                               ArrayList<String> statusValues,
                               ArrayList<String> packageValues) {
        this.activity = activity;
        this.imageValues = new ArrayList<>();
        this.titleValues = new ArrayList<>();
        this.versionValues = new ArrayList<>();
        this.statusValues = new ArrayList<>();
        this.packageValues = new ArrayList<>();
        filterInstalledGames(imageValues, titleValues, versionValues, statusValues, packageValues);
    }

    private void filterInstalledGames(ArrayList<Integer> imageValues, ArrayList<String> titleValues,
                                      ArrayList<String> versionValues, ArrayList<String> statusValues,
                                      ArrayList<String> packageValues) {
        for (int i = 0; i < packageValues.size(); i++) {
            if (AppUtils.isAppInstalled(packageValues.get(i))) {
                this.imageValues.add(imageValues.get(i));
                this.titleValues.add(titleValues.get(i));
                this.versionValues.add(versionValues.get(i));
                this.statusValues.add(statusValues.get(i));
                this.packageValues.add(packageValues.get(i));
            }
        }
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View listItem = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_games, parent, false);
        return new MyViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.gameIcon.setImageResource(imageValues.get(position));
        holder.gameTitle.setText(titleValues.get(position));
        holder.gameVersion.setText(versionValues.get(position));

        testanjing(holder.okBtn, holder.status, packageValues.get(position));

        holder.okBtn.setOnClickListener(v -> {
            if (statusValues.get(position).equals("Maintenance") || statusValues.get(position).equals("Coming Soon")) {
                toastImage(R.drawable.icon, "App is currently under: " + statusValues.get(position));
            } else {
                activity.doShowProgress(true);
                doInstallAndRun(holder, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return imageValues.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private ImageView gameIcon;
        private TextView gameTitle;
        private TextView gameVersion;
        private TextView status;
        private FrameLayout okBtn;

        public MyViewHolder(View itemView) {
            super(itemView);
            gameIcon = itemView.findViewById(R.id.gameIcon);
            gameTitle = itemView.findViewById(R.id.gameTitle);
            gameVersion = itemView.findViewById(R.id.gameVersion);
            okBtn = itemView.findViewById(R.id.okBtn);
            status = itemView.findViewById(R.id.status);
        }
    }

    public void testanjing(FrameLayout game, TextView status, String pkg) {
        activity.runOnUiThread(() -> {
            if (BlackBoxCore.get().isInstalled(pkg, 0)) {
                status.setText("فتح اللعبه");
            } else {
                status.setText("غير مثبت");
            }
        });

        game.setOnLongClickListener(v -> {
            activity.showBottomSheetDialog(
                    activity.getResources().getDrawable(R.drawable.icon_toast_alert),
                    activity.getString(R.string.confirm),
                    activity.getString(R.string.want_remove_it),
                    false,
                    sv -> {
                        activity.doShowProgress(true);
                        unInstallWithDelay(pkg);
                        activity.dismissBottomSheetDialog();
                    },
                    v1 -> activity.dismissBottomSheetDialog()
            );
            return false;
        });
    }

    // ----------------------------
    // ✅ myCopyTask2 style OBB copy + run
    // ----------------------------
    private void doInstallAndRun(MyViewHolder holder, int position) {
    if (activity == null) {
        ToastUtils.showLong("Null Activity");
        return;
    }

    activity.CURRENT_PACKAGE = packageValues.get(position);
    Handler handler = new Handler(Looper.getMainLooper());
    handler.post(() -> {
        String pkg = packageValues.get(position);

        // ✅ Auto-detect OBB file
        File obbDir = new File("/storage/emulated/0/Android/obb/" + pkg);
        File[] files = obbDir.listFiles((dir, name) -> name.startsWith("main.") && name.endsWith(".obb"));

        if (files == null || files.length == 0) {
            Toast.makeText(activity, "ملف OBB غير موجود في Android/obb", Toast.LENGTH_LONG).show();
            activity.doHideProgress();
            return;
        }

        File sourceFile = files[0];
        File destFile = new File("/storage/emulated/0/blackbox/Android/obb/" + pkg + "/" + sourceFile.getName());

        if (destFile.exists()) {
            // ✅ Already copied → launch directly
            installOrLaunch(holder, pkg, position);
        } else {
            // ✅ Ask user before copying
            new AlertDialog.Builder(activity)
                    .setTitle("نسخ ملف OBB")
                    .setMessage("هل تريد نسخ ملف OBB الآن؟")
                    .setPositiveButton("نعم", (dialog, which) -> {
                        copyObbFileWithProgress(activity, holder, pkg, sourceFile, destFile);
                    })
                    .setNegativeButton("إلغاء", (dialog, which) -> {
                        // cancel copy → just run game directly
                        installOrLaunch(holder, pkg, position);
                    })
                    .setCancelable(false)
                    .show();
        }
    });
}


    private void copyObbFileWithProgress(NeroActivity activity, MyViewHolder holder,
                                         String pkg, File source, File dest) {
        View customLayout = LayoutInflater.from(activity).inflate(R.layout.dialog_loading2, null);
        ProgressBar progressBar = customLayout.findViewById(R.id.progress_bar);
        TextView progressText = customLayout.findViewById(R.id.progress_text);

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setView(customLayout)
                .setCancelable(false)
                .create();
        dialog.show();

        ExecutorService executor = Executors.newSingleThreadExecutor();
        Handler uiHandler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            boolean success = false;
            String errorMsg = null;

            try {
                dest.getParentFile().mkdirs();

                try (FileInputStream in = new FileInputStream(source);
                     FileOutputStream out = new FileOutputStream(dest)) {

                    long total = source.length();
                    long copied = 0;
                    byte[] buffer = new byte[4096];
                    int read;
                    while ((read = in.read(buffer)) != -1) {
                        out.write(buffer, 0, read);
                        copied += read;
                        int progress = (int) ((copied * 100) / total);
                        uiHandler.post(() -> {
                            progressBar.setProgress(progress);
                            progressText.setText(progress + "%");
                        });
                    }
                }
                success = true;
            } catch (Exception e) {
                errorMsg = e.getMessage();
            }

            boolean finalSuccess = success;
            String finalErrorMsg = errorMsg;
            uiHandler.post(() -> {
                dialog.dismiss();
                if (finalSuccess) {
                    Toast.makeText(activity, "تم نسخ ملف OBB بنجاح!", Toast.LENGTH_LONG).show();
                    installOrLaunch(holder, pkg, packageValues.indexOf(pkg));
                } else {
                    Toast.makeText(activity, finalErrorMsg != null ? finalErrorMsg : "فشل النسخ!", Toast.LENGTH_LONG).show();
                    activity.doHideProgress();
                }
            });
        });
    }

    private void installOrLaunch(MyViewHolder holder, String pkg, int position) {
    if (BlackBoxCore.get().isInstalled(pkg, 0)) {
        activity.doHideProgress();
        BlackBoxCore.get().launchApk(pkg, 0);
        holder.status.setText("فتح اللعبه");

        // ✅ Trigger floater safely via NeroActivity
        activity.triggerFloaterFromAdapter();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (gameint >= 1 && gameint <= 4) {
                Exec("/chemistry");
            } else if (gameint == 5) {
                Exec("/chemistry");
            }
        }, 15000);

    } else {
        InstallResult result = BlackBoxCore.get().installPackageAsUser(pkg, 0);
        if (result.success) {
            activity.doHideProgress();
            BlackBoxCore.get().launchApk(pkg, 0);
            holder.status.setText("فتح اللعبه");

            // ✅ After install, also trigger floater
            activity.triggerFloaterFromAdapter();
        } else {
            activity.doHideProgress();
            FLog.error("Install failed: " + result.msg);
        }
    }
}


    // ----------------------------
    // Other Helpers
    // ----------------------------
    public void Exec(String path) {
        try {
            ExecuteElf("chmod 777 " + activity.getFilesDir() + path);
            ExecuteElf(activity.getFilesDir() + path);
        } catch (Exception ignored) {}
    }

    private void ExecuteElf(String shell) {
        try {
            Runtime.getRuntime().exec(shell, null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void unInstallWithDelay(String packageName) {
        UiKit.defer().when(() -> {
            long time = System.currentTimeMillis();
            BlackBoxCore.get().uninstallPackageAsUser(packageName, 0);
            time = System.currentTimeMillis() - time;
            long delta = 500L - time;
            if (delta > 0) {
                UiKit.sleep(delta);
            }
        }).done((res) -> {
            activity.doInitRecycler();
            activity.doHideProgress();
            toastImage(R.drawable.ic_check, packageName + " was successfully uninstalled.");
        });
    }
}
