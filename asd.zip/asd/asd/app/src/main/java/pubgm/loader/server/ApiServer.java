package pubgm.loader.server;

import pubgm.loader.utils.FLog;
import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

public class ApiServer {

    public static ApiServer AppChecker;

    static {
        try {
            System.loadLibrary("master");
        } catch(UnsatisfiedLinkError w) {
            FLog.error(w.getMessage());
        }
    }

    public static native String mainURL();
    public static native String getOwner();
    public static native String getTelegram();
    public static native String activity();
    public static native String ApiKeyBox();
    public static native String EXP();
    public static native String URLJSON();

}

